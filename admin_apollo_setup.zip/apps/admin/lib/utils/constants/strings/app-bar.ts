export const ZONE = 'Zone';
export const DISPATCH = 'Dispatch';
export const SETTINGS = 'Settings';
export const LANGUAGE = 'EN';
