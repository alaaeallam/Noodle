export const APP_NAME = 'Yalla';
export const LOGO_URL = '/';
