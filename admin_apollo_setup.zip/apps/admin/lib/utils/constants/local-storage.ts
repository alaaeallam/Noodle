export const SELECTED_VENDOR_EMAIL = 'selected-vendor-email';
export const SELECTED_RESTAURANT = 'restaurantId';
export const SELECTED_VENDOR = 'vendorId';
export const SELECTED_SIDEBAR_MENU = 'selected-sidebar-menu';
export const SELECTED_SHOPTYPE = 'shopType';
