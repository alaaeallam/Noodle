export const VEHICLE_TYPE = [
  { label: 'Bicycle', code: 'bicycle' },
  { label: 'Motorbike', code: 'motorbike' },
  { label: 'Car', code: 'car' },
  { label: 'Pickup Truck', code: 'pickup_truck' },
];
