export const COMMISSION_RATE_ACTIONS = {
  MORE_THAN_5: 'More than 5%',
  MORE_THAN_10: 'More than 10%',
  MORE_THAN_20: 'More than 20%',
};
