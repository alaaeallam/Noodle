export const SHOP_TYPE = [
  {
    label: 'Grocery',
    code: 'grocery',
  },
  {
    label: 'Restaurant',
    code: 'restaurant',
  },
];

export const RESTAURANTS_TABS: string[] = ['Actual', 'Cloned'];
