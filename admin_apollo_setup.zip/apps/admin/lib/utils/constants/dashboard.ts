export const DASHBOARD_PAYMENT_METHOD = {
  all: 'All',
  cod: 'COD',
  card: 'Card',
};

export const DASHBOARD_PAYMENT_METHOD_SUB_TITLE = {
  all: 'All',
  isPickedUp: 'Pickup',
  isNotPickedUp: 'Delivery',
};
