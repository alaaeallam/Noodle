export interface ICouponErrors {
  title: string[];
  discount: string[];
  enabled: string[];
}
