export interface ICuisineErrors {
  name: string[];
  description: string[];
  shopType: string[];
  image: string[];
}
