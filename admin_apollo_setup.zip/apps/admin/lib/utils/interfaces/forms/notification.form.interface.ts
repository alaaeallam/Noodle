export interface INoticiationErrors {
  _id?: string[];
  title: string[];
  body: string[];
  createdAt?: string[];
  updatedAt?: string[];
}
