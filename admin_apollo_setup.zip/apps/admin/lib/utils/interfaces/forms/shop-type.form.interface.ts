export interface IShopTypeErrors {
  title: string[];
  image: string[];
  isActive: string[]
}
