export interface IGlobalSVGProps {
  height?: string;
  width?: string;
  strokeColor?: string;
}
