export interface IGenericTableColumn {
  field: string;
  header: string;
}
