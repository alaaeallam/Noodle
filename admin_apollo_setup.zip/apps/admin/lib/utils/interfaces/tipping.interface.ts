import { IGlobalComponentProps } from './global.interface';

export interface ITippingHeaderComponentsProps extends IGlobalComponentProps {}
