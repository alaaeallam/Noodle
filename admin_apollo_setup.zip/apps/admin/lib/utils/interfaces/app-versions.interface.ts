export interface IVersionConfigForm {
  customerAppVersionAndroid: string;
  customerAppVersionIos: string;
  riderAppVersionAndroid: string;
  riderAppVersionIos: string;
  restaurantAppVersionAndroid: string;
  restaurantAppVersionIos: string;
}