import { IGlobalComponentProps } from './global.interface';

export interface ITextComponentProps extends IGlobalComponentProps {
  text: string;
}
