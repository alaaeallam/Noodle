export interface ICountryCodes {
  name: string;
  label: string;
  value: string;
}
