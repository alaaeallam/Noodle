export type TTextCase = 'lower' | 'upper' | 'title';
