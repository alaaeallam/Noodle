export type TLocale = 'en';
