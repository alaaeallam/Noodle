export type TToastSeverity = 'error' | 'success' | 'info' | 'warn';
