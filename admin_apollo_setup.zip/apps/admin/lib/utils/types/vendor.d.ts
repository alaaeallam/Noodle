export type TVendorFormPosition =
  | 'top'
  | 'bottom'
  | 'left'
  | 'right'
  | undefined;

export type TVendorMobileTabs = 'vendors' | 'restaurants';
