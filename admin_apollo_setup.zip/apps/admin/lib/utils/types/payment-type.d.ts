export type TPaymentType = 'paypal' | 'stripe';
