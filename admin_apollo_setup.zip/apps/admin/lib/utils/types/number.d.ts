export type TNumberMode = 'decimal' | 'currency' | undefined;
