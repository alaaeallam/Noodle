export const locales: string[] = ['ar', 'de', 'en', 'fr', 'km', 'zh'];
